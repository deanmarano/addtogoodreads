Add to Goodreads
============

A simple Google Chrome extension that extracts a valid ISBN number from the current tab
and loads the "Add to my books" (http://www.goodreads.com/api/atmb_widget) widget. This hack
allows a user to easily add a book to one of the default shelves without requiring any special authentication (other than being logged in to the site). 

See Chrome store entry:

 https://chrome.google.com/webstore/detail/add-to-goodreads/lfpebbhpojbhmeaolnjdofjeihhgncbe?hl=en&gl=US
 
## Disclaimer:

I don't have any prior experience with Javascript or Google Chrome. I wrote this mostly to solve a small problem, and it does for me.

Please feel free to fork, contribute, offer advice, etc...
